//
// Created by 20174019 on 14/06/2021.
//

#include "Object.h"

void draw_object() {};
std::vector<Vec2f> get_points() { return std::vector<Vec2f>({(0.0)}); };