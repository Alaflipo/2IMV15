#include "Object.h"

void draw_object() {};
std::vector<Vec2f> get_points() { return std::vector<Vec2f>({(0.0)}); };